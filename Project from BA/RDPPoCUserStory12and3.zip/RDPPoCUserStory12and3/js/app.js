$(document).ready(function () {
    var numberOFPass = 1, numberOfInfant = 0, count = 2, totalNumberOfInfant = 0;
    var dataConcat = $("#viewDepartLocation_orig").text() + " - " + $("#viewArriveLocation_input").text() + "." + $("#viewDepartDate").text() + " - " + $("#viewReturnDate").text() + "." + $("#viewPaxMix").text() + "." + $("#viewFlightCabin").text();
    $("#viewSearchParam").text(dataConcat);
    function travellersRoomWidth() {
        var travellers_room_width;
        if ($(this).width() <= 782) {
            travellers_room_width = $(".travellers-container").width();
            $('.room-travellers-details').css("width", travellers_room_width);
        } else if ($(this).width() >= 783) {
            travellers_room_width = ($(".from").width() + $(".to").width() + $(".dates").width() + $(".travellers-container").width()) + 12;
            $('.room-travellers-details').css("width", travellers_room_width);
        }
    }

    $(window).resize(function () {
        travellersRoomWidth();
    });

    $("#flightClass_").change(function () {
        var selected_option = $("#flightClass_ option:selected").val();
        var selected_option_value = "flightClass_" + selected_option;
        $("#" + selected_option_value).addClass("selected");
        $('span[id^="flightClass_"]').addClass("de-selected");
        $("#" + selected_option_value).removeClass("de-selected");
    });

    $('span[id^="flightClass_"]').click(function () {
        var slected_id = $(this).attr('id');
        $("#" + slected_id).addClass("selected");
        $('span[id^="flightClass_"]').addClass("de-selected");
        $("#" + slected_id).removeClass("de-selected");
        var split_slected_id = slected_id.split("_");
        $('#flightClass_').val(split_slected_id[1]);
    });

    $(".changeSearchBtn").click(function () {
        $("#changeSearchSection").hide();
        $("#expand").show();
        travellersRoomWidth();
    });
    $(".cancelSearch").click(function (e) {
        e.preventDefault();
        $("#changeSearchSection").show();
        $("#expand").hide();
    });

    $('.passenger-count-part').hide();
    $('.show-full-data').hide();
    function addNumbers(count) {

        $("#passengerCountPart_" + count).hide();
        var adultid = "#numAdultsRoom_" + count;
        $(adultid).val(1);
        numberOFPass = numberOFPass + 1;

    }

    function getTheValue(id) {
        var adultVal = 0, childVal = 0, infantVal = 0;
        adultVal = $('#numAdultsRoom_' + id).val();
        childVal = $('#numChildrenRoom_' + id).val();
        infantVal = $('#numInfantsRoom_' + id).val();
        setTheValue(id, adultVal, childVal, infantVal);

    }

    function setTheValue(id, adultVal, childVal, infantVal) {
        var adultToVal = 0, childToVal = 0, infantToVal = 0;
        adultToVal = $('#passengerAdultCountPart_' + id).text(adultVal);
        childToVal = $('#passengerChildCountPart_' + id).text(childVal);
        infantToVal = $('#passengerInfantCountPart_' + id).text(infantVal);
        $('#show_' + id).show();
        $('#downArrow_' + id).show();
    }

    $(document).on('click', '#numRooms', function () {

        if (numberOFPass > 8) {
            console.log('maximum added');
        } else {
            if (count < 5) {
                var $addinput = $('<div  class="row dynamically-added-item" >' +
                    '<div class="small-12 large-12 columns room-container">' +
                    '<div class="room-remove-room-container"><div class="room">Room ' + count + '</div>' +
                    '<div class="remove-room remove-room-link" id="removeRoom_' + count + '">Remove room</div></div>' +
                    ' <div class="right" >' +
                    '<div class="primary show-full-data" id="show_' + count + '" >' +
                    '<span aria-hidden="true" data-icon="&#xe601;" class="down-arrow" style="display: none;"  id="downArrow_' + count + '"></span>' +
                    '<span aria-hidden="true" data-icon="&#xe60c;" class="up-arrow" style="display: none;" id="upArrow_' + count + '"></span>' +
                    '</div>' +
                    '</div>' +
                    '<div id="passengerCountPart_' + count + '" class="passenger-count-part">' +
                    '<div class="row">' +
                    ' <div class="travellers-room-inner-container">' +
                    '<div class="travellers-room-inner-title">' +
                    '<span  class = "inner-adult-count-div"  id="passengerAdultCountPart_' + count + '"></span>' +
                    '</div>' +
                    '<div class="travellers-room-inner-title">' +
                    '&nbsp;Adult,' +
                    '</div>' +
                    '</div>' +
                    '<div class="travellers-room-inner-child-container">' +
                    '<div class="travellers-room-inner-title">' +
                    '<span  class = "inner-child-count-div" id="passengerChildCountPart_' + count + '"></span>' +
                    '</div>' +
                    '<div class="travellers-room-inner-title">' +
                    '&nbsp;Child,' +
                    '</div>' +
                    '</div>' +
                    '<div class="travellers-room-inner-container">' +
                    '<div class="travellers-room-inner-title">' +
                    '<span class = "inner-infant-count-div"  id="passengerInfantCountPart_' + count + '">' +
                    '</span>' +
                    '</div>' +
                    '<div class="travellers-room-inner-title">' +
                    '&nbsp;Infant' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="passenger-add" id="passengerAddPart_' + count + '">' +
                    '<div class="counter counter-container">' +
                    '<div class="row">' +
                    '<div class="small-4 medium-12 columns room-travellers-details-title">' +
                    '<span>Adult</span>' +
                    '<span class="link">18+</span>' +
                    '</div>' +
                    '<div class="small-8 medium-12 columns adult-container">' +
                    '<button type="button" class="counter--decrease counter--range math-operation" name="minus">' +
                    '<span aria-hidden="true" data-icon="&#xe61a;"></span>' +
                    '</button>' +
                    '<input type="number" class="counter--input highlight" readonly value="0" id="numAdultsRoom_' + count + '"/>' +
                    '<button type="button" class="counter--increase counter--range math-operation" name="addition">' +
                    '<span aria-hidden="true" data-icon="&#xe61b;"></span>' +
                    '</button>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row adult-warning">' +
                    '<div class="small-8 columns  small-push-4">' +
                    '<span class="adult-message" id="msgAdultsRoom_' + count + '">' +
                    'The total number of passengers (excluding infants) must not exceed 9. Find out about group travel bookings.</span>' +
                    '<span class="mismatch-infant-message" id="msgmismatchInfantRoom_' + count + '">' +
                    'For safety reasons, the number of infants travelling cannot exceed the number of adults.</span>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="counter counter-container">' +
                    '<div class="row">' +
                    '<div class="small-4 medium-12 columns room-travellers-details-title">' +
                    '<span>Children</span>' +
                    '<span class="link">2-17</span>' +
                    '</div>' +
                    '<div class="small-8 medium-12 columns  child-container">' +
                    '<button type="button" class="counter--decrease counter--range math-operation" name="minus">' +
                    '<span aria-hidden="true" data-icon="&#xe61a;"></span>' +
                    '</button>' +
                    '<input type="number" class="counter--input highlight" readonly value="0" id="numChildrenRoom_' + count + '"/>' +
                    '<button type="button" class="counter--increase counter--range math-operation" name="addition">' +
                    '<span aria-hidden="true" data-icon="&#xe61b;"></span>' +
                    '</button>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row child-warning">' +
                    '<div class="small-8 columns child-message small-push-4" id="childMessage_' + count + '">' +
                    'The total number of passengers (excluding infants) must not exceed 9. Find out about group travel bookings.' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<div class="counter counter-container">' +
                    '<div class="row">' +
                    '<div class="small-4 medium-12 columns room-travellers-details-title">' +
                    '<span>Infants</span>' +
                    '<span class="link">Under-2</span>' +
                    '</div>' +
                    '<div class="small-8 medium-12 columns  infant-container">' +
                    '<button type="button" class="counter--decrease counter--range infan-operation" name="minus">' +
                    '<span aria-hidden="true" data-icon="&#xe61a;"></span>' +
                    '</button>' +
                    '<input type="number" class="counter--input highlight" readonly value="0" id="numInfantsRoom_' + count + '"/>' +
                    '<button type="button" class="counter--increase counter--range infan-operation" name="addition">' +
                    '<span aria-hidden="true" data-icon="&#xe61b;"></span>' +
                    '</button>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row infant-warning">' +
                    '<div class="small-8 columns small-push-4">' +
                    '<span class="infant-message" id="infantMessage_' + count + '">' +
                    'For safety reasons, the number of infants travelling cannot exceed the number of adults.</span>' +
                    '<span class="max-infant-message" id="maxInfant_' + count + '">' +
                    'The total number of infants must not exceed 8.</span>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>');
                var passengerAddedPart = '#passengerAddPart_' + parseInt(count - 1);
                $('#passengerCountPart_' + parseInt(count - 1)).show();
                $(passengerAddedPart).hide();
                getTheValue(parseInt(count - 1));
                $("#addHotelRoom").append($addinput);
                $(".adult-message,.mismatch-infant-message ,div.child-message, span.infant-message, span.max-infant-message").hide();
                addNumbers(count);
                count++;

                if (count === 5) {
                    $("#numRooms").hide();
                } else {
                    $("#numRooms").show();
                }

            }
        }

    });

    $(".adult-message,.mismatch-infant-message ,div.child-message, span.infant-message, span.max-infant-message").hide();
    $(document).on('click', '.infan-operation', function () {
        $(".adult-message,.mismatch-infant-message ,div.child-message, span.infant-message, span.max-infant-message").hide();
        var newVal, $button, oldValue, adultValue, currentId, adultId, messageIdVal = '';
        $button = $(this);
        oldValue = $button.parent().find("input").val();
        currentId = $button.parent().find("input").attr("id");
        adultId = "#numAdultsRoom_" + currentId.split("_")[1];
        adultValue = $(adultId).val();

        if ($button[0].name === 'addition') {
            if (adultValue > oldValue && oldValue < 9) {
                newVal = parseFloat(oldValue) + 1;
                $button.parent().find("input").val(newVal);
                numberOfInfant = newVal;
                totalNumberOfInfant = totalNumberOfInfant + 1;
            } else {
                if ($button.parent().attr('class').indexOf("infant-container") > 0 && oldValue < 8) {
                    messageIdVal = "#infantMessage_" + currentId.split("_")[1];
                    $(messageIdVal).hide();
                    $('.max-infant-message').hide()
                } else {
                    messageIdVal = "#maxInfant_" + currentId.split("_")[1];
                    $(".infant-message").hide();
                    $(messageIdVal).hide()
                }
            }
        }
        else {
            if (oldValue > 0) {
                newVal = parseFloat(oldValue) - 1;
                totalNumberOfInfant = totalNumberOfInfant - 1;
            } else {
                newVal = 0;
            }
            $button.parent().find("input").val(newVal);
            numberOfInfant = newVal;
        }
    });
    $(document).on('click', '.math-operation', function () {
        $(".adult-message,.mismatch-infant-message ,div.child-message, span.infant-message, span.max-infant-message").hide();
        var newVal, $button, oldValue, currentId = '', messageId = '';
        $button = $(this);
        oldValue = $button.parent().find("input").val();
        currentId = $button.parent().find("input").attr("id");
        if ($button[0].name === 'addition') {
            if (numberOFPass < 9) {
                numberOFPass = parseInt(numberOFPass) + 1;
                newVal = parseFloat(oldValue) + 1;
                $button.parent().find("input").val(newVal);
                $(".infant-message").hide();
            } else {
                $button.parent().find("input").val(oldValue);
                if ($button.parent().attr('class').indexOf("adult-container") > 0) {
                    messageId = "#msgAdultsRoom_" + currentId.split("_")[1];
                    $(".child-message").hide();
                    $(messageId).hide();
                } else if ($button.parent().attr('class').indexOf("child-container") > 0) {
                    messageId = "#childMessage_" + currentId.split("_")[1];
                    $(".adult-message").hide();
                    $(messageId).hide();
                }
                return;
            }
        }
        else {
            if (oldValue > 1) {
                if (parseInt(oldValue) <= numberOfInfant && !($button.parent().attr('class').indexOf("child-container") > 0)) {
                    messageId = "#msgmismatchInfantRoom_" + currentId.split("_")[1];
                    $(messageId).hide();
                    return;
                } else {
                    numberOFPass = numberOFPass - 1;
                    newVal = parseFloat(oldValue) - 1;
                }

            } else {
                if ($button.parent().attr('class').indexOf("child-container") > 0) {
                    newVal = 0;

                } else {
                    newVal = 1;
                }
                var onZero = 0;
                $.each($('div.room'), function (i, j) {
                    onZero = onZero + parseInt($('#numAdultsRoom_' + parseInt(i + 1)).val()) + parseInt($('#numChildrenRoom_' + parseInt(i + 1)).val());
                });
                numberOFPass = onZero;
            }
            $button.parent().find("input").val(newVal);
        }
    });
    $(document).on('click', '.remove-room', function () {
        var idVal = 0, adultCount = 0, childCount = 0, totalPassenger = 0, infantCount = 0;
        adultCount = $('#numAdultsRoom_' + $(this).attr('id').split('_')[1]).val();
        childCount = $('#numChildrenRoom_' + $(this).attr('id').split('_')[1]).val();
        infantCount = $('#numInfantsRoom_' + $(this).attr('id').split('_')[1]).val();
        totalPassenger = parseInt(adultCount) + parseInt(childCount);
        $(this).parent().parent().parent().remove();
        $.each($("div.dynamically-added-item"), function (i, el) {
            $(this).find(".room-remove-room-container").find(".room").text('Room ' + parseInt(i + 2));
            $(this).find(".room-remove-room-container").find('.remove-room').attr("id", "removeRoom_" + parseInt(i + 2));
            $(this).find('.adult-warning').find('.adult-message').attr("id", "msgAdultsRoom_" + parseInt(i + 2));
            $(this).find('.adult-warning').find('.mismatch-infant-message').attr("id", "msgmismatchInfantRoom_" + parseInt(i + 2));
            $(this).find('.adult-container').find('.counter--input').attr("id", "numAdultsRoom_" + parseInt(i + 2));
            $(this).find('.child-container').find('.counter--input').attr("id", "numChildrenRoom_" + parseInt(i + 2));
            $(this).find('.child-warning').find('.child-message').attr("id", "childMessage_" + parseInt(i + 2));
            $(this).find('.infant-container').find('.counter--input').attr("id", "numInfantsRoom_" + parseInt(i + 2));
            $(this).find('.infant-warning').find('.infant-message').attr("id", "infantMessage_" + parseInt(i + 2));
            $(this).find('.infant-warning').find('.max-infant-message').attr("id", "maxInfant_" + parseInt(i + 2));
            $(this).find('.room-container').find('.show-full-data').attr("id", "show_" + parseInt(i + 2));
            $(this).find('.room-container').find('.show-full-data').find('.down-arrow').attr("id", "downArrow_" + parseInt(i + 2));
            $(this).find('.room-container').find('.show-full-data').find('.up-arrow').attr("id", "upArrow_" + parseInt(i + 2));
            $(this).find('.room-container').find('.passenger-count-part').attr("id", "passengerCountPart_" + parseInt(i + 2));
            $(this).find('.room-container').find('.passenger-add').attr("id", "passengerAddPart_" + parseInt(i + 2));
            $(this).find('.room-container').find('.passenger-count-part').find('.inner-adult-count-div').attr("id", "passengerAdultCountPart_" + parseInt(i + 2));
            $(this).find('.room-container').find('.passenger-count-part').find('.inner-child-count-div').attr("id", "passengerChildCountPart_" + parseInt(i + 2));
            $(this).find('.room-container').find('.passenger-count-part').find('.inner-infant-count-div').attr("id", "passengerInfantCountPart_" + parseInt(i + 2));

        });
        numberOFPass = numberOFPass - totalPassenger;
        totalNumberOfInfant = totalNumberOfInfant - infantCount;
        count--;
        $("#numRooms").show();
    });
    $(document).on('click', '.show-full-data', function () {
        var $button = $(this);
        var currentId = $button.attr("id");
        var justId = $button.attr("id").split("_");
        var countId = "#passengerCountPart_" + currentId.split("_")[1];
        var detailId = "#passengerAddPart_" + currentId.split("_")[1];
        getTheValue(justId[1]);
        $.each($('div.room'), function (i, j) {
        });
        if ($(countId + ':visible').length == 1) {
            $(countId).hide();
            $(detailId).css("display", "inline-block");
            $("#downArrow_" + justId[1]).hide();
            $("#upArrow_" + justId[1]).show();
        } else {
            $(detailId).hide();
            $(countId).show();
            $("#downArrow_" + justId[1]).show();
            $("#upArrow_" + justId[1]).hide();
        }

        return;
    });

    $("#room,#roomTravellers").click(function () {
        if ($("#roomTravellersDetails").is(":visible")) {
            $('#room').val(parseInt(totalNumberOfInfant + numberOFPass) + 'Travellers,' + parseInt(count - 1) + 'Room');
        }
        $("#roomTravellersDetails").slideToggle();
        $("#roomTravellersDetails").css("display", "inline-block");

    });

    $("#expandFlightDetails").click(function () {
        $(".flight-details-container").hide();
        $("#expandedFlightDetails").show();

    });

    $("#hideFlightDetails").click(function () {
        $(".flight-details-container").show();
        $("#expandedFlightDetails").hide();

    });
    $("#toArrow").click(function (e) {
        e.preventDefault();
        $("#arriveLocation_input").val("");
    });
    $(".searchSubmit").click(function (e) {
        e.preventDefault();
        var arriveLocation_input = $("#arriveLocation_input").val();
        var room = $("#room").val();
        var departDate = $("#departDate").val();

        if (arriveLocation_input == "" || arriveLocation_input.length < '3') {
            $(".error").css("display", "block");
        } else {
            $(".error").css("display", "none");
        }

        if (room == "") {
            $(".travellers-error").css("display", "block");
        } else {
            $(".travellers-error").css("display", "none");
        }

        if (departDate == "" || departDate == null) {
            $(".date-error").css("display", "block");
        } else {
            $(".date-error").css("display", "none");
        }

    });

    $(document).foundation();
    var popup = new Foundation.Reveal($('#feedbackModal'));
    var confirmPopup = new Foundation.Reveal($('#feedbackConfirm'));
    $('div.feedbackLink, div.feed-back-button-container').on('click', function () {
        $('#feedbackModal').find('form')[0].reset();
        popup.open();
    });
    $('a.close-reveal-modal').on('click', function () {
        $(this).parent().find('form')[0].reset();
        popup.close();
    });
    $('.send-feedback').on("click", function (ev) {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if ($('#feedBackForm')[0].email.value === '') {
            $(this).parent().parent().children().has('small.alert').children('label').addClass('is-invalid-label');
            $(this).parent().parent().children().has('small.alert').children().children('input').addClass('is-invalid-label');
            $('#feedBackForm')[0].email.focus();
            ev.preventDefault();
        } else if (!emailReg.test($('#feedBackForm')[0].email.value)) {
            $(this).parent().parent().children().has('small.alert').children('label').addClass('is-invalid-label');
            $(this).parent().parent().children().has('small.alert').children().children('input').addClass('is-invalid-label');
            $('#feedBackForm')[0].email.focus();
            ev.preventDefault();
        } else if ($.trim($('#feedBackForm')[0].comment.value) === '') {
            $(this).parent().parent().children().has('small.alert').children('label').addClass('is-invalid-label');
            $(this).parent().parent().children().has('small.alert').children().children('textarea').addClass('is-invalid-label');
            $('#feedBackForm')[0].comment.focus();
            ev.preventDefault();
        } else {
            confirmPopup.open();
        }
        // confirmPopup.open();
        ev.preventDefault();
    });

    $('button.feedback-continue').on('click', function () {
        confirmPopup.close();
    });

});


