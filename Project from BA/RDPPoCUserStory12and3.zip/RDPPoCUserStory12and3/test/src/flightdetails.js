﻿var onReady = function(){
    $("#expandFlightDetails").click(function () {
        $(".flight-details-container").hide();
        $("#expandedFlightDetails").show();

    });

    $("#hideFlightDetails").click(function () {
        $(".flight-details-container").show();
        $("#expandedFlightDetails").hide();

    });
};
$(document).ready(onReady);
