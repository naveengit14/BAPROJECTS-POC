﻿describe("Flight selection module", function () {
    beforeEach(function () {
        setFixtures('<div id="expandFlightDetails" class="div">' +
            '<div class="flight-details-container" style="display: none">Y</div>' +
            '</div>' +
            '<div id="hideFlightDetails" class="div">' +
            '<div id="expandedFlightDetails" style="display: none">Z</div>' +
            '</div>'
        );
    });
    it("Initiating click event for expanding/showing flight details page", function () {
        onReady();
        var spyEvent = spyOnEvent('#expandFlightDetails', 'click');
        $('#expandFlightDetails').click();
        expect('click').toHaveBeenTriggeredOn('#expandFlightDetails');
        expect(spyEvent).toHaveBeenTriggered();
    });
    it("expand the flight details part on clicking the ID #expandFlightDetails ", function () {
        onReady();
        $('#expandFlightDetails').click();
        expect($(".flight-details-container")).toBeHidden();
    });
    it("Initiating click event for hiding flight details page", function () {
        onReady();
        var spyEvent = spyOnEvent('#hideFlightDetails', 'click');
        $('#hideFlightDetails').click();
        expect('click').toHaveBeenTriggeredOn('#hideFlightDetails');
        expect(spyEvent).toHaveBeenTriggered();
    });
    it("expand the flight details part on clicking the ID #hideFlightDetails ", function () {
        onReady();
        $('#hideFlightDetails').click();
        expect($("#expandedFlightDetails")).toBeHidden();
    });
});