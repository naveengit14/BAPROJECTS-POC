package com.ba.automation.testing.enums;

/**
 * Created by n450777 on 12/04/2016.
 */
public enum ScreenType {
    Mobile,
    Desktop,
    Tablet
}
