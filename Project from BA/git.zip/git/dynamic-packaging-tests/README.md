# Dynamic packaging tests

This repository contains UI tests for dynamic packaing platform.

# Running tests instructions

1. Clone the repo
1. Open in IntelliJ
1. Run a feature file by right clicking