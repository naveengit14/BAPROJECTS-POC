# selenium-pom-example

Example project supporting https://github.com/sponte/selenium-pom
