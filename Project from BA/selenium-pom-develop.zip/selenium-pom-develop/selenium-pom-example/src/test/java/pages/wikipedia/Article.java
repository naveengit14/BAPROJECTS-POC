package pages.wikipedia;

import uk.sponte.automation.seleniumpom.PageElement;

/**
 * Created by n450777 on 30/11/2015.
 */
public class Article {

    public PageElement firstHeading;
}
