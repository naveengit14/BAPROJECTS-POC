package uk.sponte.automation.seleniumpom.testobjects.pages;

/**
 * Test page object
 */
public class MobileHomepageImpl extends Homepage {
}
