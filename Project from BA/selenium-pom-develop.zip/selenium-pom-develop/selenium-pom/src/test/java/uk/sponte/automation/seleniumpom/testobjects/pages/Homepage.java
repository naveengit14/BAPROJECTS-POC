package uk.sponte.automation.seleniumpom.testobjects.pages;

import uk.sponte.automation.seleniumpom.PageElement;

/**
 * Test page object
 */
public class Homepage {
    PageElement loginButton;
}
