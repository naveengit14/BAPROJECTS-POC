package uk.sponte.automation.seleniumpom.annotations;

import org.openqa.selenium.By;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by n450777 on 30/04/15.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Frame {
}
