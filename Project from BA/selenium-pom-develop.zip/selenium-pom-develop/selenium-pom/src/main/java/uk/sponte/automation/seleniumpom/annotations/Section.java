package uk.sponte.automation.seleniumpom.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by n450777 on 07/04/15.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Section {
}
