package uk.sponte.automation.seleniumpom.annotations;

/**
 * Validator based class, used in @PageFilter
 */
public interface Validator {
    boolean isValid();
}
