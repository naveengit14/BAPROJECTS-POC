package uk.sponte.automation.seleniumpom.exceptions;

/**
 * Created by n450777 on 07/04/15.
 */
public class PageFactoryError extends Error {
    public PageFactoryError(Throwable cause) {
        super(cause);
    }
}
