﻿function Selection() {

}
Selection.prototype.expandFlightDetails = function() {

    document.getElementsByClassName("flight-details-container")[0].style.display = 'none';
    document.getElementById("expandedFlightDetails").style.display = 'block';
};
Selection.prototype.hideFlightDetails = function() {
    document.getElementById("expandedFlightDetails").style.display = 'none';
    document.getElementsByClassName("flight-details-container")[0].style.display = 'block';

};