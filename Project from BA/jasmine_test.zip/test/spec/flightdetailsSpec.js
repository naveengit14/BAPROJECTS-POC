﻿describe("Test Case for flight selection module", function() {
    var selection;

    beforeAll(function () {
        selection= new Selection();
        var seconddummyElement = document.createElement('div');
        seconddummyElement.className = 'flight-details-container';
        seconddummyElement.style.cssText = 'display:none';
        document.body.appendChild(seconddummyElement);
        var dummyElement = document.createElement('div');
        dummyElement.id = 'expandedFlightDetails';
        dummyElement.style.cssText = 'display:none';
        document.body.appendChild(dummyElement);
    });
    it('expand the flight details part ' , function(){
        selection.expandFlightDetails();
        expect(document.body.getElementsByClassName('flight-details-container')[0].style.display).toEqual('none');

    });
    it('hide the flight details part ', function(){
        selection.hideFlightDetails();
        expect(document.getElementById('expandedFlightDetails').style.display).toEqual('none');

    });
});